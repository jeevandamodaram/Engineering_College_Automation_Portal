<?php

$page=$_GET["page"];

$cyear=date("Y");
$z=0;

//echo "$zas";
//echo "$b";
//$_POST['mark'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "DELETE FROM studet WHERE pyear=4 AND edu='b' ";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$mconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$mconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$msql =  "DELETE FROM mid WHERE pyear=4 AND edu='b' ";


if ($mconn->query($msql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$misql =  "DELETE FROM midi WHERE pyear=4 AND edu='b' ";

if ($miconn->query($misql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$miisql =  "DELETE FROM midii WHERE pyear=4 AND edu='b' ";


if ($miiconn->query($miisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}







$aiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$aiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$aisql = "DELETE FROM bati WHERE pyear=4 AND edu='b' "; 
if ($aiconn->query($aisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $aisql . "<br>" . $aiconn->error;
}


$dlconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$dlconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$dlsql = "UPDATE  del SET b4='1' ";


if ($dlconn->query($dlsql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $dlsql . "<br>" . $conn->error;
}


header("location:$page");
mysqli_close($conn);
?> 




