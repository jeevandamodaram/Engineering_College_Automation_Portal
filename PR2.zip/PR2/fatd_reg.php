 <?php
$fac=$_GET["fac"];
$sub=$_GET["sub"];
$page=$_GET["pg"];
$table=$_GET["table"];
$uid=$_GET["uid"];
$tm=$_REQUEST["tm"];

echo"$sub";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$asql = "UPDATE $table SET  $sub='$tm' WHERE fname='$fac' AND ufid='$uid' ";

if ($conn->query($asql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

header("location: $page ");
mysqli_close($conn);
?> 




