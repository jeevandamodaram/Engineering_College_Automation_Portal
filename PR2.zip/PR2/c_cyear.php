<?php

$page="clear_stu.php";

//$s=2;

//echo "$zas";
//echo "$b";
//$_POST['mark'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE studet SET mstatus='1',astatus='1' WHERE pyear=3 AND edu='b' ";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$mconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$mconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$msql = "UPDATE mid SET m='1',s1='0',s2='0',s3='0',s4='0',s5='0',s6='0',L1='0',L2='0',atd='0' WHERE pyear=3 AND edu='b' ";


if ($mconn->query($msql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$misql = "UPDATE midi SET s1='0',s2='0',s3='0',s4='0',s5='0',s6='0',L1='0',L2='0' WHERE pyear=3 AND edu='b' ";

if ($miconn->query($misql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$miisql =  "UPDATE midii SET s1='0',s2='0',s3='0',s4='0',s5='0',s6='0',L1='0',L2='0' WHERE pyear=3 AND edu='b' ";


if ($miiconn->query($miisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}







$aiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$aiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$aisql = "UPDATE bati SET m='1',s1='0',s2='0',s3='0',s4='0',s5='0',s6='0',l1='0',l2='0' WHERE pyear=3 AND edu='b' ";
if ($aiconn->query($aisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $aisql . "<br>" . $aiconn->error;
}


$dlconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$dlconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$dlsql = "UPDATE  stuclear SET c='2' WHERE sem='1'  ";


if ($dlconn->query($dlsql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $dlsql . "<br>" . $conn->error;
}


header("location:$page");
mysqli_close($conn);
?> 




