<?php

$page="clear_fac.php";

//$s=2;

//echo "$zas";
//echo "$b";
//$_POST['mark'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE bfaculty SET qsi='N',qli='N',wsi='N',wli='N',esi='N',eli='N',rsi='N',rli='N' WHERE sem1='1' ";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$mconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$mconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$msql = "UPDATE fbati SET s1='N',s2='N',s3='N',s4='N',s5='N',s6='N',l1='N',l2='N',m='1' WHERE sem='1' ";


if ($mconn->query($msql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$misql = "UPDATE fbatii SET s1='N',s2='N',s3='N',s4='N',s5='N',s6='N',l1='N',l2='N',m='1' WHERE sem='1' ";

if ($miconn->query($misql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$miisql = "UPDATE fbatiii SET s1='N',s2='N',s3='N',s4='N',s5='N',s6='N',l1='N',l2='N',m='1' WHERE sem='1' ";


if ($miiconn->query($miisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}







$aiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$aiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$aisql = "UPDATE fbatiiii SET s1='N',s2='N',s3='N',s4='N',s5='N',s6='N',l1='N',l2='N',m='1' WHERE sem='1' ";
if ($aiconn->query($aisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $aisql . "<br>" . $aiconn->error;
}


$dlconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$dlconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$dlsql = "UPDATE  facclear SET a='2' WHERE sem='1'  ";


if ($dlconn->query($dlsql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $dlsql . "<br>" . $conn->error;
}


header("location:$page");
mysqli_close($conn);
?> 




