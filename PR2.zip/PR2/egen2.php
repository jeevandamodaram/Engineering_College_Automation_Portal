<?
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$aconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$aconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$asql = "SELECT * FROM msi WHERE semester='2'  ";
$aresult = mysqli_query($aconn, $asql);
while($arow = mysqli_fetch_assoc($aresult)) {
$s1=$arow['s1'];
$s2=$arow['s2'];
$s3=$arow['s3'];
$s4=$arow['s4'];
$s5=$arow['s5'];
$s6=$arow['s6'];
$l1=$arow['l1'];
//$l2=$arow['l2'];
}
//echo"$s1";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$zsql = "SELECT mfname FROM mfaculty WHERE  mwsi='$s1' ";
$zresult = mysqli_query($conn, $zsql);
while($zrow = mysqli_fetch_assoc($zresult)) {
$as = $zrow['mfname'];
}
//echo"$s1";echo"$as";
$bsql = "SELECT mfname FROM mfaculty WHERE  mwsi='$s2' ";
$bresult = mysqli_query($conn, $bsql);
while($brow = mysqli_fetch_assoc($bresult)) {
$bs = $brow['mfname'];
}
$csql = "SELECT mfname FROM mfaculty WHERE  mwsi='$s3' ";
$cresult = mysqli_query($conn, $csql);
while($row = mysqli_fetch_assoc($cresult)) {
$cs = $row['mfname'];}

$dsql = "SELECT mfname FROM mfaculty WHERE  mwsi='$s4' ";
$dresult = mysqli_query($conn, $dsql);
while($row = mysqli_fetch_assoc($dresult)) {
$ds = $row['mfname'];}

$esql = "SELECT mfname FROM mfaculty WHERE  mwsi='$s5' ";
$eresult = mysqli_query($conn, $esql);
while($row = mysqli_fetch_assoc($eresult)) {
$es = $row['mfname'];}

$fsql = "SELECT mfname FROM mfaculty WHERE  mwsi='$s6' ";
$fresult = mysqli_query($conn, $fsql);
while($row = mysqli_fetch_assoc($fresult)) {
$fs = $row['mfname'];}

$gsql = "SELECT mfname FROM mfaculty WHERE  mwli='$l1' ";
$gresult = mysqli_query($conn, $gsql);
while($row = mysqli_fetch_assoc($gresult)) {
$gl = $row['mfname'];}


?> 