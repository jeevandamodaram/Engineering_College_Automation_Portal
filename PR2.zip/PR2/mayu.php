<?php

$page=$_GET["page"];

$cyear=date("Y");

$z=0;
//echo "$zas";
//echo "$b";
//$_POST['mark'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE studet SET pyear='2', cyear='$cyear' WHERE pyear=1 AND edu='m' ";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$mconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$mconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$msql =  "UPDATE mid SET pyear='2', cyear='$cyear' WHERE pyear=1 AND edu='m' ";


if ($mconn->query($msql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$misql =  "UPDATE midi SET pyear='2', cyear='$cyear' WHERE pyear=1 AND edu='m' ";

if ($miconn->query($misql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$miiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$miiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$miisql =  "UPDATE midii SET pyear='2', cyear='$cyear' WHERE pyear=1 AND edu='m' ";


if ($miiconn->query($miisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$aiconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$aiconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$aisql = "UPDATE mati SET  s1='$z', s2='$z', s3='$z', s4='$z', s5='$z', s6='$z', l1='$z', l2='$z', m1='$z', m2='$z', m3='$z', m='$z',  pyear='2', cyear='$cyear' WHERE pyear=1 AND edu='m' ;";
if ($aiconn->query($aisql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $aisql . "<br>" . $aiconn->error;
}





$dlconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$dlconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$dlsql = "UPDATE  del SET m1='0' ";
if ($dlconn->query($dlsql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $dlsql . "<br>" . $conn->error;
}


$adlconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$adlconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$adlsql = "UPDATE  del SET m2='1' ";
if ($adlconn->query($adlsql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $adlsql . "<br>" . $adlconn->error;
}


header("location:$page");
mysqli_close($conn);
?> 




