<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


//$sub="ADSA"; 
$edu="m";
$pid="1";
$s5="s5";
$page="iet2s5.php";

$ssql = "SELECT s5 FROM msi  WHERE sem= '2' ";
$sresult = mysqli_query($conn, $ssql);
while($brow = mysqli_fetch_assoc($sresult)) {
$sub = $brow['s5'];
}



$fsql = "SELECT mfname FROM mfaculty  WHERE mwsi='$sub' ";
$fresult = mysqli_query($conn, $fsql);
while($arow = mysqli_fetch_assoc($fresult)) {
$fac = $arow['mfname'];
}

$xsql = "SELECT s2 FROM fmati  WHERE mfname='$fac' ";
$xresult = mysqli_query($conn, $xsql);
while($xrow = mysqli_fetch_assoc($xresult)) {
$total = $xrow['s2'];
}





//echo "$s5    ";

?>
<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>


<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th {padding:5px; border:1px solid #ac8f57;background-color:#85144b;color:#fff }
.myTable td {padding:0px; border:1px solid #ac8f57;}
</style>
      <script>
 
 function autoRefresh()
{
	window.location = window.location.href;
}
 
 setInterval('autoRefresh()', 5000); // this will reload page after every 5 secounds; Method I
</script>

	</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation"><ul>
		 	<li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="mainstu.php">SDPS</a>&nbsp;</li>
			<li><a href="mainfac.php">FDPS</a>&nbsp;</li>
			<li><a href="mainsub.php">SSPS</a>&nbsp;</li>
			<li><a href="mainmks.php">IMPS</a>&nbsp;</li>
			<li><a href="mainats.php">SAPS</a>&nbsp;</li>
         </ul>	</div>

</div>


<div id="top2">

	 <table align="center" class="myTable" width="90%"  border="0" style="border-collapse: collapse; margin-top:2.5%; ">
	  
          <tr> <th width="25%" style="font-size:18px;" > M.Tech  I<sup>st</sup> Year &nbsp;&nbsp;</th> <th width="25%"  style="font-size:18px;" >II<sup>nd</sup> Semester </th>
		  <th width="25%" style="font-size:18px; color:#93EAA3" > <? echo "$sub"; ?> </th>
		  <th width="25%" style="font-size:18px; color:#fbf799" ><? echo "$fac"; ?> </th>
		  </tr>
		</table>
</div>



<div id="top3">

</div>



<div id="top14">
 
	
		 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$qconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$qconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$count=1;
$qsql = "SELECT * FROM mati WHERE pyear='$pid' AND edu='$edu'    ORDER BY rno ASC ";
$qresult = mysqli_query($qconn, $qsql);
while($qrow = mysqli_fetch_assoc($qresult)) {
	
//echo "$s";
echo "<form  method='post' action='atd_reg1.php?stid=". $qrow['stid'] ." & rno=". $qrow['rno'] ." & sub= ".$s5."  & pg= ".$page." & pid= ".$pid." & total= ".$total." '>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo "<td  width='5%' ><p align='center' style='font-size:20px; color:#85144b'>" . $count++ .  " </p> </td>";
echo "<td  width='12%'bgcolor='#85144b'><p align='center' style='font-size:20px; color:#FFFFFF'>" . $qrow["rno"].  " </p> </td>";
echo "<td  width='25%'><p align='center' style='font-size:20px; color:#85144b'><strong>". $qrow["sname"].  "</strong> </p> </td>";
echo " <td width='14%'>";
echo " <input class='minput' name='marks'  type='number' min=1  maxlength='2' placeholder=". $qrow["s5"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";

echo "<td  width='10%' >  <button class='button1'> Update </button> </td>";

echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'>" . $qrow["s5"].  " </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'>" . $total.  " </p> </td>";



echo"
</tr>
<tr>
</tr>
</table>
</form>";

}
?> 
		

	
	
		

</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
