
<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th {  padding:12px;border:1px solid #ac8f57;background-color:#85144b;color:#fff }
.myTable td{ padding:2px;border:1px solid #ac8f57; }
</style>
    
	</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation">
         <ul> <li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="mainstu.php">SDPS</a>&nbsp;</li>
			<li><a href="mainfac.php">FDPS</a>&nbsp;</li>
			<li><a href="mainsub.php">SSPS</a>&nbsp;</li>
			<li><a href="mainmks.php">IMPS</a>&nbsp;</li>
			<li><a href="mainats.php">SAPS</a>&nbsp;</li>
            
           
		</ul>	
			
     </div>

</div>



<div id="top2">
	<p align="center" style=" color:#FFFFFF; font-size:30px; font-family:'Times New Roman', Times, serif"><strong>Welcome to Internal Marks Panel Service [ IMPS ]   </strong></p>
</div>



<div id="top3">

</div>



<div id="top4">

	  <table align="center" class="myTable" width="80%" style="border-collapse: collapse">
          <tr><th colspan="10" style="font-size:20px;">B.Tech [ Computer Science & Engg ] </th></tr>

	      <tr> 

            <td width="5%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF; font-size:18px;"><strong>I<sup>st</sup> Year </strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="bt1s1.php">SEMESTER 1</a></strong></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="bt1s2.php">SEMESTER 2</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

           <td width="5%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF;font-size:18px;"><strong>II<sup>nd</sup> Year </strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="bt2s1.php">SEMESTER 1</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="bt2s2.php">SEMESTER 2</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

            <td width="5%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF;font-size:18px;"><strong>III<sup>rd</sup> Year </strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="bt3s1.php">SEMESTER 1</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="bt3s2.php">SEMESTER 2</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

            <td width="5%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF;font-size:18px;"><strong>IV<sup>rd</sup> Year </strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="bt4s1.php">SEMESTER 1</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="bt4s2.php">SEMESTER 2</a></strong></h4></center></td>
			
            </tr>
		
	
        </table>
		
		<br>
		
			  <table align="center" class="myTable" width="80%" style="border-collapse: collapse">
          <tr><th colspan="10" style="font-size:20px;">M.Tech [ Computer Science & Engg ] </th></tr>

	      <tr> 

        <td width="5%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF;font-size:18px;"><strong>I<sup>st</sup> Year </strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="mt1s1.php">SEMESTER 1</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="mt1s2.php">SEMESTER 2</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

            <td width="5%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF;font-size:18px;"><strong>II<sup>nd</sup> Year </strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="#">Project 1 [ 4 Months]</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="#">Project 1.2 [ 4 Months ]</a></strong></h4></center></td>
			
            </tr>
		
		 
		
	
        </table>
	
	
		

</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
