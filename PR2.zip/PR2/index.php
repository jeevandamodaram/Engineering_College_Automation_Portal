
<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>


<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th { background-color:#85144b;color:#fff }
.myTable td, .myTable th { padding:5px;border:1px solid #ac8f57; }
</style>
    
	</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation">
         <ul>
		 	<li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="mainstu.php">SDPS</a>&nbsp;</li>
			<li><a href="mainfac.php">FDPS</a>&nbsp;</li>
			<li><a href="mainsub.php">SSPS</a>&nbsp;</li>
			<li><a href="mainmks.php">IMPS</a>&nbsp;</li>
			<li><a href="mainats.php">SAPS</a>&nbsp;</li>
         </ul>	
			
     </div>

</div>


<div id="top2">
		<p align="center" style=" color:#FFFFFF; font-size:30px; font-family:'Times New Roman', Times, serif"><strong>Welcome to Internal Server Services  </strong></p>
</div>



<div id="top3">

</div>



<div id="top14">



 
	  <table align="center" class="myTable" width="50%" style="border-collapse: collapse">
	  
          <tr>
		  <th align="center" style="font-size:22px;" >Services Panel List</th>
		 
		  </tr>
		</table>
		
<?php
echo "<form  method='post' action='mainstu.php'>";
echo "<table align='center' class='myTable' width='50%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong> Student Details Panel [ SDP ] </strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?> 
		
	
<?php
echo "<form  method='post' action='mainfac.php'>";
echo "<table align='center' class='myTable' width='50%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong>Faculty Details Panel [ FDP ]</strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?>
<?php
echo "<form  method='post' action='mainsub.php'>";
echo "<table align='center' class='myTable' width='50%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong>Semester Syllabus Panel [ SSP ]</strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?> 
<?php
echo "<form  method='post' action='mainmks.php'>";
echo "<table align='center' class='myTable' width='50%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong>Internal Marks Panel [ IMP ]</strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?> 		
<?php
echo "<form  method='post' action='mainats.php'>";
echo "<table align='center' class='myTable' width='50%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong>Semester Attendance Panel [ SAP ] </strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?> 	
	
	<br>
	<br><br>
	
	
	  <table align="center" class="myTable" width="65%" style="border-collapse: collapse">
	  
          <tr>
		  <th align="center" style="font-size:22px;" >Attendance '&' Internal Marks Generate '&' Print  Panel</th>
		 
		  </tr>
		</table>
		
	<?php
echo "<form  method='post' action='maingen.php'>";
echo "<table align='center' class='myTable' width='65%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong>Attendance & Internals Generate Panel</strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?> 	
<?php
echo "<form  method='post' action='mainprint.php'>";
echo "<table align='center' class='myTable' width='65%' style='border-collapse: collapse'>";
//$s=$row['midI']; 
//}
echo "<tr>"; 
echo"<td align='center' width='72%' style='font-size:22px; color:#85144b'  width='80%'><strong>Attendance & Internals Print Panel  </strong> </td>";
echo "<td  width='28%' >  <button class='button1'> Click Here </button> </td>";
echo"
</tr>
<tr>
</tr>
</table>
</form>";
?> 	
	
		

</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
