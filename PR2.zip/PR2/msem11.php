<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script src="js/jquery.unslider.js"></script>
<script type="text/javascript" src="js/s3Slider.js"></script>
  <script>
    // You can also use "$(window).load(function() {"
    $(function () {

      $("#slider1").responsiveSlides({ speed: 200});

    });
  </script>
<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th { background-color:#85144b;color:#fff }
.myTable td, .myTable th { padding:5px;border:1px solid #ac8f57; }
</style>
    
	</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation">
         <ul>
		 	 <li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="im.php">Internals Panel</a>&nbsp;</li>
            <li><a href="aboutus.php">Atendence Panel</a>&nbsp;</li>
           
		</ul>	
			
     </div>

</div>


<div id="top2">
	
</div>



<div id="top3">

</div>



<div id="top14">

	  <table align="center" class="myTable" width="80%" style="border-collapse: collapse">
	  
	  	 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$assql = "SELECT s1 FROM msi  WHERE sem= '1' ";
$asresult = mysqli_query($conn, $assql);
while($asrow = mysqli_fetch_assoc($asresult)) {
$s1 = $asrow['s1'];
}
$bssql = "SELECT s2 FROM msi  WHERE sem= '1' ";
$bsresult = mysqli_query($conn, $bssql);
while($bsrow = mysqli_fetch_assoc($bsresult)) {
$s2 = $bsrow['s2'];
}

$cssql = "SELECT s3 FROM msi  WHERE sem= '1' ";
$csresult = mysqli_query($conn, $cssql);
while($csrow = mysqli_fetch_assoc($csresult)) {
$s3 = $csrow['s3'];
}
$dssql = "SELECT s4 FROM msi  WHERE sem= '1' ";
$dsresult = mysqli_query($conn, $dssql);
while($dsrow = mysqli_fetch_assoc($dsresult)) {
$s4 = $dsrow['s4'];
}
$essql = "SELECT s5 FROM msi  WHERE sem= '1' ";
$esresult = mysqli_query($conn, $essql);
while($esrow = mysqli_fetch_assoc($esresult)) {
$s5 = $esrow['s5'];
}
$fssql = "SELECT s6 FROM msi  WHERE sem= '1' ";
$fsresult = mysqli_query($conn, $fssql);
while($fsrow = mysqli_fetch_assoc($fsresult)) {
$s6 = $fsrow['s6'];
}
$gssql = "SELECT l1 FROM msi  WHERE sem= '1' ";
$gsresult = mysqli_query($conn, $gssql);
while($gsrow = mysqli_fetch_assoc($gsresult)) {
$l1 = $gsrow['l1'];
}





$asql = "SELECT mfname FROM mfaculty WHERE  mqsi='$s1' ";
$aresult = mysqli_query($conn, $asql);
while($arow = mysqli_fetch_assoc($aresult)) {
$s1 = $arow['mfname'];}

$bsql = "SELECT mfname FROM mfaculty WHERE  mqsi='$s2' ";
$bresult = mysqli_query($conn, $bsql);
while($row = mysqli_fetch_assoc($bresult)) {
$s2 = $row['mfname'];}

$csql = "SELECT mfname FROM mfaculty WHERE  mqsi='$s3' ";
$cresult = mysqli_query($conn, $csql);
while($row = mysqli_fetch_assoc($cresult)) {
$s3 = $row['mfname'];}

$dsql = "SELECT mfname FROM mfaculty WHERE  mqsi='$s4' ";
$dresult = mysqli_query($conn, $dsql);
while($row = mysqli_fetch_assoc($dresult)) {
$s4 = $row['mfname'];}

$esql = "SELECT mfname FROM mfaculty WHERE  mqsi='$s5' ";
$eresult = mysqli_query($conn, $esql);
while($row = mysqli_fetch_assoc($eresult)) {
$s5 = $row['mfname'];}

$fsql = "SELECT mfname FROM mfaculty WHERE  mqsi='$s6' ";
$fresult = mysqli_query($conn, $fsql);
while($row = mysqli_fetch_assoc($fresult)) {
$s6 = $row['mfname'];}

$gsql = "SELECT mfname FROM mfaculty WHERE  mqli='$l1' ";
$gresult = mysqli_query($conn, $gsql);
while($row = mysqli_fetch_assoc($gresult)) {
$l1 = $row['mfname'];}
?>



<tr><th colspan="10" style="font-size:20px; color:#FFFFFF"> M.Tech  I<sup>st</sup> Year[CSE ] , &nbsp;&nbsp;I<sup>st</sup> SEMESTER </th></tr>
		  

<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Advanced Data Structures and Alg <br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$s1"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems11.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems12.php"><strong>Internal  II</strong></a></p></td>

</tr>
						
<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Discrete Structures <br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$s2"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems21.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems22.php"><strong>Internal  II</strong></a></p></td>

</tr>

<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Computer System Design<br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$s3"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems31.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems32.php"><strong>Internal  II</strong></a></p></td>

</tr>
		
		
<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Java and Web Technologies<br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$s4"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems41.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems42.php"><strong>Internal  II</strong></a></p></td>

</tr>
		
		
		
<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Software Engineering<br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$s5"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems51.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems52.php"><strong>Internal  II</strong></a></p></td>

</tr>
		
		
<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Distributed Databases<br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$s6"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems61.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="mems62.php"><strong>Internal  II</strong></a></p></td>

</tr>
				 
		
<tr> 

<td width="10%" bgcolor="#85144b"><center><h3 align="center" style="color:#fbf799"><strong>Software Lab- 1<br/></h3>
		<h3 align="center" style="color: #93EAA3"> <? echo "$l1"; ?> </strong></h3>  </center></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="meml11.php"><strong>Internal  I</strong></a></p></td>
<td align="center" width="8%"><p style="color:#85144b;font-size:18px"><a href="meml12.php"><strong>Internal  II</strong></a></p></td>

</tr>
				
			
				
			
        </table>
		

		
		
		

	
	
		

</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
