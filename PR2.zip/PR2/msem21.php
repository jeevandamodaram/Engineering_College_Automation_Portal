<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script src="js/jquery.unslider.js"></script>
<script type="text/javascript" src="js/s3Slider.js"></script>
  <script>
    // You can also use "$(window).load(function() {"
    $(function () {

      $("#slider1").responsiveSlides({ speed: 200});

    });
  </script>
<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th { background-color:#85144b;color:#fff }
.myTable td, .myTable th { padding:5px;border:1px solid #ac8f57; }
</style>
    
	</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation">
         <ul> <li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="mainstu.php">SDPS</a>&nbsp;</li>
			<li><a href="mainfac.php">FDPS</a>&nbsp;</li>
			<li><a href="mainsub.php">SSPS</a>&nbsp;</li>
			<li><a href="mainmks.php">IMPS</a>&nbsp;</li>
			<li><a href="mainats.php">SAPS</a>&nbsp;</li>
            
           
		</ul>	
			
     </div>

</div>


<div id="top2">
	
</div>



<div id="top3">

</div>



<div id="top14">

	  <table align="center" class="myTable" width="60%" style="border-collapse: collapse">
          <tr><th colspan="10"> M.Tech  II<sup>nd</sup> Year[CSE ] , &nbsp;&nbsp;I<sup>st</sup> SEMESTER </th></tr>
		  

	      <tr> 

            <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>Subject I</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em11.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em12.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

              <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>Subject II</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em21.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em22.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

              <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>Subject III</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em31.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em32.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
		
		  <tr> 

             <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>Subject IV</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em41.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em42.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
		
	
			  <tr> 

             <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>Subject V</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em41.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em42.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
					  <tr> 

             <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>Subject VI</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em41.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em42.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
					  <tr> 

             <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>LAB I</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em41.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em42.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
			
					  <tr> 

             <td width="10%" bgcolor="#85144b"><center><h4 style="color:#FFFFFF"><strong>LAB I</strong></h4>  </center></td>
             <td width="8%"><center><h4 style="color:#85144b"><a href="em41.html">Internal  I</a></h4></center></td>
             <td width="8%"><center><h4 style="color:#85144b"><strong><a href="em42.html">Internal  II</a></strong></h4></center></td>
			
            </tr>
			
        </table>
		

		
		
		

	
	
		

</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
