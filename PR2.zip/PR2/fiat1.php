<?
include 'agen1.php';

$page="fiat1.php";
$sub="s1";
$lsub="l1";
$table="fbati";


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>


<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" /><head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
 <script>
 function autoRefresh()
{
	window.location = window.location.href;
}
 
 setInterval('autoRefresh()', 5000); // this will reload page after every 5 secounds; Method I
</script>

<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th { padding:10px;border:1px solid #ac8f57;background-color:#85144b;color:#fff }
.myTable td { padding:0px;border:1px solid #ac8f57; }
</style>
    
	</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation"><ul>
		 	<li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="mainstu.php">SDPS</a>&nbsp;</li>
			<li><a href="mainfac.php">FDPS</a>&nbsp;</li>
			<li><a href="mainsub.php">SSPS</a>&nbsp;</li>
			<li><a href="mainmks.php">IMPS</a>&nbsp;</li>
			<li><a href="mainats.php">SAPS</a>&nbsp;</li>
         </ul>	</div>

</div>


<div id="top2">
		<p align="center" style=" color:#FFFFFF; font-size:30px; font-family:'Times New Roman', Times, serif"><strong> B.Tech ::  Faculty Panel For Total Attendance  </strong></p>
</div>



<div id="top3">

</div>



<div id="top14">

<table align="center" class="myTable" width="70%" style="border-collapse: collapse">
<tr><th colspan="10" style="font-size:22px; color:#FFFFFF"> I<sup>st</sup> Year,&nbsp;'&' &nbsp;I<sup>st</sup> Semester,&nbsp;  Enter Total Classes. </th></tr>
</table>
		
<?php
$sql = "SELECT * FROM $table WHERE fname='$as' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?fac=" . $as ." & sub=". $sub ." & pg=". $page ." & table=". $table ." &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $as  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $s1 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["s1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?> 	
<?php
$sql = "SELECT * FROM $table WHERE fname='$bs' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $bs ." & sub=". $sub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $bs  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $s2 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["s1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>
<?php
$sql = "SELECT * FROM $table WHERE fname='$cs' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $cs ." & sub=". $sub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $cs  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $s3 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["s1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>
<?php
$sql = "SELECT * FROM $table WHERE fname='$ds' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $ds ." & sub=". $sub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $ds  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $s4 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["s1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>
<?php
$sql = "SELECT * FROM $table WHERE fname='$es' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $es ." & sub=". $sub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $es  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $s5 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["s1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>
<?php
$sql = "SELECT * FROM $table WHERE fname='$fs' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $fs ." & sub=". $sub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $fs  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $s6 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["s1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>
<?php
$sql = "SELECT * FROM $table WHERE fname='$gl' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $gl ." & sub=". $lsub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $gl  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $l1 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["l1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>
<?php
$sql = "SELECT * FROM $table WHERE fname='$hl' ";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)) {
//$uid=$row['ufid'];
echo "<form  method='post' action='fatd_reg.php?pg=". $page ." & fac=" . $hl ." & sub=". $lsub ." &  table=". $table ."  &  uid=". $row["ufid"] ."'>";
echo "<table align='center' class='myTable' width='70%' style='border-collapse: collapse'>";
echo "<tr>"; 
echo "<td  width='15%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $hl  .  "</strong> </p> </td>";
echo "<td  width='10%' ><p align='center' style='font-size:20px; color:#85144b'><strong>" . $l2 .  "</strong> </p> </td>";
echo " <td width='10%'>";
echo " <input class='minput' name='tm'  type='number' min=1 max=90 maxlength='2' placeholder=". $row["l1"]. "  required style='font-weight: bold; font-family: Century Gothic; color: #85144b' /></td>";
echo "<td  width='6%' >  <button class='button1'> Update </button> </td>";
echo"
</tr>
</table>
</form>";
}
?>




	
	
		

</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
