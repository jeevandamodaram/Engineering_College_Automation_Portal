<?php

$uid=uniqid();
$fid= $uid;
$mfid= $uid;
$a=$_REQUEST["fname"];
$b=$_REQUEST["edts"];
$c=$_REQUEST["fdg"];


//echo "$a";
//echo "$pid";
//echo "$s";
//echo "$page";

//echo "$b";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$asql = "INSERT INTO bfaculty (fid, fname , edet, deg ) VALUES ('$fid', '$a', '$b', '$c' )";
if ($conn->query($asql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}


$bsql = "INSERT INTO mfaculty (mfid, mfname , edet, deg ) VALUES ('$mfid', '$a', '$b', '$c' )";
if ($conn->query($bsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$csql = "INSERT INTO fbati (fid, fname ) VALUES ('$mfid', '$a' )";
if ($conn->query($csql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$dsql ="INSERT INTO fbatii (fid, fname ) VALUES ('$mfid', '$a' )";
if ($conn->query($dsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$esql = "INSERT INTO fbatiii (fid, fname ) VALUES ('$mfid', '$a' )";
if ($conn->query($esql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$fsql ="INSERT INTO fbatiiii (fid, fname ) VALUES ('$mfid', '$a' )";
if ($conn->query($fsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$gsql ="INSERT INTO fmati (mfid, mfname ) VALUES ('$mfid', '$a' )";
if ($conn->query($gsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$hsql ="INSERT INTO fmatii (mfid, mfname ) VALUES ('$mfid', '$a' )";
if ($conn->query($hsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}



header("location:faculty.php ");

mysqli_close($conn);
?> 




