<?php
$fid=$_GET["id"];

$mfid= $fid;

$a=$_REQUEST["fname"];
$b=$_REQUEST["edts"];
$c=$_REQUEST["fdg"];


//echo "$a";
//echo "$pid";
//echo "$s";
//echo "$page";

//echo "$b";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$asql = "UPDATE bfaculty SET fname ='$a', edet='$b', deg='$c' WHERE fid='$fid'  ";
if ($conn->query($asql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}


$bsql = "UPDATE mfaculty SET mfname ='$a', edet='$b', deg='$c' WHERE mfid='$mfid'  ";
if ($conn->query($bsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}


$csql = "UPDATE fbati SET fname ='$a'  WHERE fid='$fid'  ";
if ($conn->query($csql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$dsql = "UPDATE fbatii SET fname ='$a' WHERE fid='$fid'  ";
if ($conn->query($dsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$esql =  "UPDATE fbatiii SET fname ='$a'  WHERE fid='$fid'  ";
if ($conn->query($esql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$fsql = "UPDATE fbatiiii SET fname ='$a' WHERE fid='$fid'  ";
if ($conn->query($fsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$gsql = "UPDATE fmati SET mfname ='$a' WHERE mfid='$mfid'  ";
if ($conn->query($gsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

$hsql ="UPDATE fmatii SET mfname ='$a' WHERE mfid='$mfid'  ";
if ($conn->query($hsql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}


header("location:faculty.php ");

mysqli_close($conn);
?> 




