 <?php
$stid=$_GET["stid"];
$a=$_GET["rno"];
$sub=$_GET["sub"];
$page=$_GET["pg"];
$pid=$_GET["pid"];
$total=$_GET["total"];
$s1=$_REQUEST["marks"];



if($total>=$s1){
 $ts1="$s1";
}else if ($total<$s1){
$ts1="0";
}
else{
$print = "ERROR";
}


//echo "$sub";
//echo "$s1";
//echo "$a";
//echo "$page";
//echo "$pid";
//echo "$edu";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$asql = "UPDATE mati SET  $sub='$ts1' WHERE stid='$stid' OR rno='$a' AND pyear='$pid'    ";

if ($conn->query($asql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

header("location: $page ");
mysqli_close($conn);
?> 




