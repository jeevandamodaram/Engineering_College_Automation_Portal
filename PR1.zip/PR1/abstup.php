<?php
$stid=uniqid();
$page=$_GET["page"];
$e=$_GET["pid"];
$edu=$_GET["edu"];
$a=$_POST["sname"];
$b=$_POST["rno"];
$c=$_POST["byear"];
$d=$_POST["cyear"];
$z='0';



//echo "$zas";
//echo "$b";
//$_POST['mark'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO studet (stid, sname, rnumber, byear , cyear ,pyear ,edu) VALUES ('$stid', '$a', '$b', '$c' , '$d','$e','$edu')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


$asql=("INSERT INTO mid (stid, rno, name,cyear, pyear ,edu ) VALUES ('$stid','$b', '$a','$d' ,'$e','$edu')");
if (mysqli_query($conn, $asql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $asql . "<br>" . mysqli_error($conn);
}

$bsql=("INSERT INTO midi (stid, rno, name,cyear, pyear ,edu ) VALUES ('$stid','$b', '$a','$d' ,'$e','$edu')");
if (mysqli_query($conn, $bsql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $bsql . "<br>" . mysqli_error($conn);
}
$csql=("INSERT INTO midii (stid, rno, name,cyear, pyear ,edu ) VALUES ('$stid','$b', '$a','$d' ,'$e','$edu')");
if (mysqli_query($conn, $csql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $csql . "<br>" . mysqli_error($conn);
}
$dsql=("INSERT INTO bati (stid, rno, sname, s1, s2, s3, s4, s5, s6, l1, l2, m1, m2, m3, m, pyear, edu,cyear) VALUES ('$stid','$b', '$a','$z','$z','$z','$z','$z','$z','$z','$z','$z','$z','$z','$z','$e','$edu','$d' )");
if (mysqli_query($conn, $dsql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $dsql . "<br>" . mysqli_error($conn);
}
$esql=("UPDATE  del SET b1='0'");
if (mysqli_query($conn, $esql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $esql . "<br>" . mysqli_error($conn);
}





header("location:$page");
$conn->close();

?> 




