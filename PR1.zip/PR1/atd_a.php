<?

$rno=$_GET['rno'];
$stid=$_GET['stid'];
//$page="at1.php"
//$rno="11099A020";
//$stid="589d7b31361f1";


?>
<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th { color:#fff }
.myTable td, .myTable th { padding:5px;border:1px solid #ac8f57; }
</style>
    
	</head>
    
<body bgcolor="#FFFFFF">




<div id="itop4">

 <form>
	   <table align="center" class="myTable" width="80%" style="border-collapse: collapse">
          <tr>
<th width="20%" style="font-size:14px; color:#000000">Roll Number</th>
<th width="7%" style="font-size:14px; color:#000000">S1</th>
<th width="7%" style="font-size:14px; color:#000000">S2</th>
<th width="9%" style="font-size:14px; color:#000000">S3</th>
<th width="7%" style="font-size:14px; color:#000000">S4</th>
<th width="8%" style="font-size:14px; color:#000000">S5</th>
<th width="7%" style="font-size:14px; color:#000000">S6</th>
<th width="7%" style="font-size:14px; color:#000000">L1</th>
<th width="9%" style="font-size:14px; color:#000000">L2</th>
<th width="19%" style="font-size:14px; color:#000000">Attendance</th>
</tr>

	
<?  


 
 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

		

//attendance


	
$bsql = "SELECT * FROM bati  WHERE stid='$stid' OR rnumber='$rno' AND pyear='1' AND edu='b'  ";
$bresult = mysqli_query($conn, $bsql);
 $count=1;
while($brow = mysqli_fetch_array($bresult))
{
$bis1= $brow['s1'];
$bis2= $brow['s2'];
$bis3= $brow['s3'];
$bis4= $brow['s4'];
$bis5= $brow['s5'];
$bis6= $brow['s6'];
$bil1= $brow['l1'];
$bil2= $brow['l2'];
} 


//echo"$bis1"; 
//echo"$bis2"; 
//echo"$bis3"; 
//echo"$bis4"; 
//echo"$bis5"; 
//echo"$bis6"; 
//echo"$bil1"; 
//echo"$bil2"; 

include 'agen2.php';

$csql = "SELECT s1 FROM fbati WHERE fname='$as' ";
$cresult = mysqli_query($conn, $csql);
while($crow = mysqli_fetch_array($cresult))
{
$fbis1= $crow['s1'];
}

$dsql = "SELECT s1 FROM fbati WHERE fname='$bs' ";
$dresult = mysqli_query($conn, $dsql);
while($drow = mysqli_fetch_array($dresult))
{
$fbis2= $drow['s1'];
}

$esql = "SELECT s1 FROM fbati WHERE fname='$cs' ";
$eresult = mysqli_query($conn, $esql);
while($erow = mysqli_fetch_array($eresult))
{
$fbis3= $erow['s1'];
}

$fsql = "SELECT s1 FROM fbati WHERE fname='$ds' ";
$fresult = mysqli_query($conn, $fsql);
while($frow = mysqli_fetch_array($fresult))
{
$fbis4= $frow['s1'];
}

$gsql = "SELECT s1 FROM fbati WHERE fname='$es' ";
$gresult = mysqli_query($conn, $gsql);
while($grow = mysqli_fetch_array($gresult))
{
$fbis5= $grow['s1'];
}

$hsql = "SELECT s1 FROM fbati WHERE fname='$fs' ";
$hresult = mysqli_query($conn, $hsql);
while($hrow = mysqli_fetch_array($hresult))
{
$fbis6= $hrow['s1'];
}

$isql = "SELECT s1 FROM fbati WHERE fname='$gl' ";
$iresult = mysqli_query($conn, $isql);
while($irow = mysqli_fetch_array($iresult))
{
$fbil1= $irow['s1'];
}

$zsql = "SELECT s1 FROM fbati WHERE fname='$hl' ";
$zresult = mysqli_query($conn, $zsql);
while($zrow = mysqli_fetch_array($zresult))
{
$fbil2= $zrow['s1'];
}


$mstu = $bis1+$bis2+$bis3+$bis4+$bis5+$bis6+$bil1+$bil2;
$mfac = $fbis1+$fbis2+$fbis3+$fbis4+$fbis5+$fbis6+$fbil1+$fbil2;
$hu="100";
$tat=(($mstu/$mfac)*($hu));

echo"$mstu";
echo"$mfac";
echo"$tat";echo"%";
echo"<br>";


echo"<tr> ";
echo"<td  align='center' width='20%' style='color:#85144b' ><strong>". $rno."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bis1. "</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bis2."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bis3."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bis4."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bis5."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bis6."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bil1."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>".$bil2."</strong></td>";

echo"</tr>";

$lsql = "UPDATE bati SET m='$tat'   WHERE stid='$stid' OR rno='$rno' AND pyear='1' AND edu='b'  ";
if ($conn->query($lsql) === TRUE) {
 header('Location :uaii.php?rno='.$rno.' & stid='.$stid.' ');
} else {
    echo "Error: " . $lsql . "<br>" . $conn->error;
}


header('Location :uaii.php?rno='.$rno.' & stid='.$stid.' ');
		
 ?>		
		
		
    </table>
	</form>		

</div>

</body>
</html>
