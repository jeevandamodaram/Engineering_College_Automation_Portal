<?  
$pid=3;
$edu='b';
?>


<!DOCTYPE html>
<html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
        <meta charset="utf-8">
               <title>Department of Computer Science & Engineering | KMMIT CSE, TIRUPATI</title>
      <link rel="stylesheet" href="css/cse.css" />
	  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
	  
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

<style type="text/css">
.myTable { background-color:;border-collapse:collapse; }
.myTable th { background-color:#FFFFFF;color:#fff }
.myTable td, .myTable th { padding:5px;border:1px solid #ac8f57; }
</style>
</head>
    
<body>


<div id="top">
	<div id="toptext">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div>
</div>


<div id="top1">
	<div id="logo"><img src="img/logo.gif" width="100px" height="80px" alt="logo"></div>
	<div id="logotext1">KMM College of Engineering.<br>Department of Computer Science & Engineering.</div>

      <div id="navigation">
         <ul> <li><a href="index.php">Home</a>&nbsp;</li>
		    <li><a href="mainstu.php">SDPS</a>&nbsp;</li>
			<li><a href="mainfac.php">FDPS</a>&nbsp;</li>
			<li><a href="mainsub.php">SSPS</a>&nbsp;</li>
			<li><a href="mainmks.php">IMPS</a>&nbsp;</li>
			<li><a href="mainats.php">SAPS</a>&nbsp;</li>
            
           
		</ul>	
			
     </div>

</div>


<div id="top2">
		<p align="center" style=" color:#FFFFFF; font-size:30px; font-family:'Times New Roman', Times, serif"><strong>B.Tech&nbsp; III<sup>rd</sup> Year, I<sup>st</sup> Semester  Attendance Update  </strong></p>
</div>



<div id="top3">

</div>



<div id="fbtop4">

 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$aconn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$aconn) {
    die("Connection failed: " . mysqli_connect_error());
}
$asql = "SELECT * FROM bsiii WHERE sem='2'  ";
$aresult = mysqli_query($aconn, $asql);
while($arow = mysqli_fetch_assoc($aresult)) {
$s1=$arow['s1'];
$s2=$arow['s2'];
$s3=$arow['s3'];
$s4=$arow['s4'];
$s5=$arow['s5'];
$s6=$arow['s6'];
$l1=$arow['l1'];
$l2=$arow['l2'];
}



$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$zsql = "SELECT fname FROM bfaculty WHERE  esi='$s1' ";
$zresult = mysqli_query($conn, $zsql);
while($zrow = mysqli_fetch_assoc($zresult)) {
$as = $zrow['fname'];

}


$bsql = "SELECT fname FROM bfaculty WHERE  esi='$s2' ";
$bresult = mysqli_query($conn, $bsql);
while($brow = mysqli_fetch_assoc($bresult)) {
$bs = $brow['fname'];

}


$csql = "SELECT fname FROM bfaculty WHERE  esi='$s3' ";
$cresult = mysqli_query($conn, $csql);
while($row = mysqli_fetch_assoc($cresult)) {
$cs = $row['fname'];}

$dsql = "SELECT fname FROM bfaculty WHERE  esi='$s4' ";
$dresult = mysqli_query($conn, $dsql);
while($row = mysqli_fetch_assoc($dresult)) {
$ds = $row['fname'];}

$esql = "SELECT fname FROM bfaculty WHERE  esi='$s5' ";
$eresult = mysqli_query($conn, $esql);
while($row = mysqli_fetch_assoc($eresult)) {
$es = $row['fname'];}

$fsql = "SELECT fname FROM bfaculty WHERE  esi='$s6' ";
$fresult = mysqli_query($conn, $fsql);
while($row = mysqli_fetch_assoc($fresult)) {
$fs = $row['fname'];}

$gsql = "SELECT fname FROM bfaculty WHERE  eli='$l1' ";
$gresult = mysqli_query($conn, $gsql);
while($row = mysqli_fetch_assoc($gresult)) {
$gl = $row['fname'];}

$hsql = "SELECT fname FROM bfaculty WHERE  eli='$l2' ";
$hresult = mysqli_query($conn, $hsql);
while($row = mysqli_fetch_assoc($hresult)) {
$hl = $row['fname'];}
?> 
	
<table align="center" class="myTable" width="95%" style="border-collapse: collapse">
<tr>
<td bgcolor="#85144b" width="4%"><center><h3 style="color:#fbf799"> Faculty </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$as"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$bs"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$cs"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$ds"; ?> </h3></center></td>


</tr>
<tr>
<td bgcolor="#85144b" width="4%"><center><h3 style="color: #93EAA3"> Subject </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$s1"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$s2"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$s3"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$s4"; ?> </h3></center></td>


</tr>
<tr>
<td bgcolor="#85144b" width="4%"><center><h3 style="color:#FFFFFF"> Update </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <a href="ict2s1.php">Click Here </a> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"><a href="ict2s2.php">Click Here </a>  </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <a href="ict2s3.php">Click Here </a>  </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <a href="ict2s4.php">Click Here </a> </h3></center></td>


</tr>
</table>	
	
<br>
<br>

<table align="center" class="myTable" width="95%" style="border-collapse: collapse">
<tr>
<td bgcolor="#85144b" width="4%"><center><h3 style="color:#fbf799"> Faculty </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$es"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$fs"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$gl"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <? echo "$hl"; ?> </h3></center></td>


</tr>
<tr>
<td bgcolor="#85144b" width="4%"><center><h3 style="color: #93EAA3"> Subject </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$s5"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$s6"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$l2"; ?> </h3></center></td>
<td width="5%"><center><h3 style="color: #85144b"> <? echo "$l2"; ?> </h3></center></td>


</tr>
<tr>
<td bgcolor="#85144b" width="4%"><center><h3 style="color:#FFFFFF"> Update </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <a href="ict2s5.php">Click Here </a> </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"><a href="ict2s6.php">Click Here </a>  </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <a href="ict2l1.php">Click Here </a>  </h3></center></td>
<td width="5%"><center><h3 style="color:#85144b"> <a href="ict2l2.php">Click Here </a> </h3></center></td>


</tr>
</table>				
</div>



<div id="afooter">
<div id="a1"><div id="a1text2">KMM COLLEGES, RAMIREDDY PALLI, TIRUPATI - 517 102 .</div></div>
</div>


</body>
</html>
