<?

$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	
$bsql = "SELECT * FROM bati  WHERE stid='$stid' OR pyear='1' AND edu='b'  ";
$bresult = mysqli_query($conn, $bsql);
while($brow = mysqli_fetch_array($bresult))
{
$bs1= $brow['s1'];
$bs2= $brow['s2'];
$bs3= $brow['s3'];
$bs4= $brow['s4'];
$bs5= $brow['s5'];
$bs6= $brow['s6'];
$bl1= $brow['l1'];
$bl2= $brow['l2'];
} 
//echo"$bis1";



$csql = "SELECT s2 FROM fbati WHERE fname='$as' ";
$cresult = mysqli_query($conn, $csql);
while($crow = mysqli_fetch_array($cresult))
{
$fbis1= $crow['s2'];
}

$dsql = "SELECT s2 FROM fbati WHERE fname='$bs' ";
$dresult = mysqli_query($conn, $dsql);
while($drow = mysqli_fetch_array($dresult))
{
$fbis2= $drow['s2'];
}

$esql = "SELECT s2 FROM fbati WHERE fname='$cs' ";
$eresult = mysqli_query($conn, $esql);
while($erow = mysqli_fetch_array($eresult))
{
$fbis3= $erow['s2'];
}

$fsql = "SELECT s2 FROM fbati WHERE fname='$ds' ";
$fresult = mysqli_query($conn, $fsql);
while($frow = mysqli_fetch_array($fresult))
{
$fbis4= $frow['s2'];
}

$gsql = "SELECT s2 FROM fbati WHERE fname='$es' ";
$gresult = mysqli_query($conn, $gsql);
while($grow = mysqli_fetch_array($gresult))
{
$fbis5= $grow['s2'];
}

$hsql = "SELECT s2 FROM fbati WHERE fname='$fs' ";
$hresult = mysqli_query($conn, $hsql);
while($hrow = mysqli_fetch_array($hresult))
{
$fbis6= $hrow['s2'];
}

$isql = "SELECT l2 FROM fbati WHERE fname='$gl' ";
$iresult = mysqli_query($conn, $isql);
while($irow = mysqli_fetch_array($iresult))
{
$fbil1= $irow['l2'];
}

$zsql = "SELECT l2 FROM fbati WHERE fname='$hl' ";
$zresult = mysqli_query($conn, $zsql);
while($zrow = mysqli_fetch_array($zresult))
{
$fbil2= $zrow['l2'];
}


$mstu = $bis1+$bis2+$bis3+$bis4+$bis5+$bis6+$bil1+$bil2;
$mfac = $fbis1+$fbis2+$fbis3+$fbis4+$fbis5+$fbis6+$fbil1+$fbil2;
$hu="100";
$tat=(($mstu/$mfac)*($hu));

echo"$mstu";
echo"$mfac";
echo"$tat";echo"%";
echo"<br>";


echo"<tr> ";
echo"<td  align='center' width='20%' style='color:#85144b' ><strong>". $rno."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bis1 . "</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bis2 ."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bis3 ."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bis4 ."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bis5 ."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bis6 ."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bil1 ."</strong></td>";
echo"<td  align='center' width='7%' style='color:#85144b' ><strong>". $bil2 ."</strong></td>";

echo"</tr>";

$lsql = "UPDATE bati SET m='$tat'   WHERE stid='$stid' OR rno='$rno' AND pyear='1' AND edu='b'  ";
if ($conn->query($lsql) === TRUE) {
 //header('Location :uaii.php?rno='.$rno.' & stid='.$stid.' ');
} else {
    echo "Error: " . $lsql . "<br>" . $conn->error;
}
?>