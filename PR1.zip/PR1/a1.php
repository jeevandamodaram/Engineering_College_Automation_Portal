<?
 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}



$amsql = "UPDATE studet SET mstatus=2 WHERE stid='$stid' OR rnumber='$rno' AND pyear='1' AND edu='b'  ";
if ($conn->query($amsql) === TRUE) {
   echo "New record created successfully";
} else {
    echo "Error: " . $amsql . "<br>" . $conn->error;
}


$bmsql = "UPDATE studet SET astatus=2 WHERE stid='$stid' OR rnumber='$rno' AND pyear='1' AND edu='b'  ";
if ($conn->query($bmsql) === TRUE) {
   echo "New record created successfully";
} else {
    echo "Error: " . $bmsql . "<br>" . $conn->error;
}

?>