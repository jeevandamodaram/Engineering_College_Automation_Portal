 <?php

$a=$_GET["rno"];
$s=$_GET["sub"];
$page=$_GET["pg"];
$pid=$_GET["pid"];
$mid=$_GET["fmid"];
$edu=$_GET["edu"];
$b=$_REQUEST["marks"];

echo "$a";
echo "$pid";
echo "$s";
echo "$page";

echo "$b";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kmmcse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "UPDATE $mid SET $s ='$b' WHERE rno='$a' or pyear='$pid' AND edu='$edu' ";

if ($conn->query($sql) === TRUE) {
    echo "success";
} else {
    echo "Error updating record: " . $conn->error;
}

header("location: $page ");
mysqli_close($conn);
?> 




